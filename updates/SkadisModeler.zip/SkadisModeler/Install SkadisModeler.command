#!/bin/bash
# SkadisModeler installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the SkadisModeler error list:"
  echo "  https://github.com/jonpikereally/skadismodeler/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing SkadisModeler…"
mkdir -p ~/Applications || fail SM-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/SkadisModeler.app
ditto --norsrc SkadisModeler.app ~/Applications/SkadisModeler.app \
  || fail SM-601 "Couldn't copy SkadisModeler into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/SkadisModeler.app 2>/dev/null
codesign --force --sign - ~/Applications/SkadisModeler.app 2>/dev/null \
  || fail SM-602 "Couldn't sign SkadisModeler for this Mac."
open ~/Applications/SkadisModeler.app \
  || fail SM-603 "SkadisModeler was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Click + to add your STL or 3MF models, then drag them around the board."
