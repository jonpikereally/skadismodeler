SkadisModeler v0.1 — see how your 3D-printed SKADIS pegboard designs fit before you print them (macOS 13+)
https://github.com/jonpikereally/skadismodeler

INSTALL
1. Double-click "Install SkadisModeler.command".
   If macOS blocks it: right-click it, choose Open, then Open again.

USE
1. Pick your board size on the right.
2. Click + (or drop files on the window) to add STL or 3MF models. Each one is
   hung on the first free slots that fit it.
3. Drag a model to move it from slot to slot. Drag the board to look around,
   scroll to zoom. Anything that overlaps, misses the slots or hangs off the
   board turns red and says why.

PRIVACY
SkadisModeler only reads the model files you add. No accounts, no analytics.
The only thing it fetches from the internet is a small version file from the
GitHub repo above, to see whether an update exists.
